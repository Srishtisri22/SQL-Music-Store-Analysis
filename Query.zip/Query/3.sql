/* Q3: What are top 3 values of total invoice? */

SELECT total 
FROM musical_database.invoice
ORDER BY total DESC
