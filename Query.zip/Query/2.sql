/* Q2: Which countries have the most Invoices? */

SELECT COUNT(*) AS c, billing_country 
FROM musical_database.invoice
GROUP BY billing_country
ORDER BY c DESC